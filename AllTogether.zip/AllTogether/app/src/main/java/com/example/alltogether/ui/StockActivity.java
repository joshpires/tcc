package com.example.alltogether.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.alltogether.R;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class StockActivity extends AppCompatActivity {
    private Button button;
    private EditText stockTxt;
    private String stock;
    public static final String  MY_FINAL_JSON = "myFinalJson";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);
        button = findViewById(R.id.stock_name_confirmation);
        stockTxt = findViewById(R.id.stock_name);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stock = stockTxt.getText().toString();
                checkStockDetails();
            }
        });
    }

    private void checkStockDetails(){
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        final InterfaceAPI api = retrofit.create(InterfaceAPI.class);

        Call<GetElementsFinalList> call = api.checkStock(stock);

        call.enqueue(new Callback<GetElementsFinalList>() {
            @Override
            public void onResponse(Call<GetElementsFinalList> call, Response<GetElementsFinalList> response) {
                if (response.isSuccessful()){
                    Toast.makeText(getApplicationContext(),"Teste com sucesso", Toast.LENGTH_LONG).show();
                    //Log.d("teste", response.body().toString());
                    Intent intent = new Intent(getApplicationContext(), GraphActivity.class);
                    intent.putExtra(MY_FINAL_JSON, new Gson().toJson(response.body()));
                    startActivity(intent);

                }
                else{
                    Toast.makeText(getApplicationContext(),"Teste deu errado", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetElementsFinalList> call, Throwable t) {
                Log.e("TAG", t.toString());
                t.printStackTrace();
                Toast.makeText(getApplicationContext(),"Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}