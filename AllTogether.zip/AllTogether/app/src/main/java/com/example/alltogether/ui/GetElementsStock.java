package com.example.alltogether.ui;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetElementsStock {

    @SerializedName("Open")
    private Float openValue;

    @SerializedName("High")
    private Float highValue;

    @SerializedName("Low")
    private Float lowValue;

    @SerializedName("Close")
    private Float closeValue;

    @SerializedName("Date")
    private String dayValue;

    public GetElementsStock (Float openValue, Float highValue, Float lowValue, Float closeValue, String dayValue){
        this.openValue = openValue;
        this.highValue = highValue;
        this.lowValue = lowValue;
        this.closeValue = closeValue;
        this.dayValue = dayValue;
    }

    public void setOpenValue(Float openValue) {
        this.openValue = openValue;
    }

    public Float getOpenValue() {
        return openValue;
    }

    public void setHighValue(Float highValue) {
        this.highValue = highValue;
    }

    public Float getHighValue() {
        return highValue;
    }

    public void setLowValue(Float lowValue) {
        this.lowValue = lowValue;
    }

    public Float getLowValue() {
        return lowValue;
    }

    public void setCloseValue(Float closeValue) {
        this.closeValue = closeValue;
    }

    public Float getCloseValue() {
        return closeValue;
    }


    public void setDayValue(String dayValue) {
        this.dayValue = dayValue;
    }

    public String getDayValue() {
        return dayValue;
    }
}
