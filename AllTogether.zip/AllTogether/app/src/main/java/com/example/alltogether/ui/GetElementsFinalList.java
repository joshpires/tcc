package com.example.alltogether.ui;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetElementsFinalList {


    @SerializedName("testeList")
    private List<GetElementsStock> finalJsonStock;

    public GetElementsFinalList (List<GetElementsStock> finalJsonStock){
        this.finalJsonStock = finalJsonStock;
    }

    public void setFinalJsonStock(List<GetElementsStock> finalJsonStock) {
        this.finalJsonStock = finalJsonStock;
    }

    public List<GetElementsStock> getFinalJsonStock() {
        return finalJsonStock;
    }
}
