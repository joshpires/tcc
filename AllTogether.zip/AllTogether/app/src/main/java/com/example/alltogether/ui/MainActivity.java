package com.example.alltogether.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alltogether.R;

public class MainActivity<buttonCreate> extends AppCompatActivity {
    private Button buttonEnter;
    private Button buttonCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonEnter = (Button) findViewById(R.id.start_button);
        buttonEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginScreen();
            }
        });

        buttonCreate = (Button) findViewById(R.id.register_button);
        buttonCreate.setOnClickListener(v -> openCreateScreen());
    }

    public void openLoginScreen(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void openCreateScreen(){
        Intent intent = new Intent(this, CreateActivity.class);
        startActivity(intent);
    }


}