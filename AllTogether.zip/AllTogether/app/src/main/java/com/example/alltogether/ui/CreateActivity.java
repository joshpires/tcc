package com.example.alltogether.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.alltogether.R;
import com.google.gson.JsonObject;

import java.io.UnsupportedEncodingException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CreateActivity extends AppCompatActivity {
    private Button button;
    private EditText nameTxt, passTxt, passTextConfirm;
    private String name, password, passwordConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        button = findViewById(R.id.confirm_create_button);
        nameTxt = findViewById(R.id.user_name_create);
        passTxt = findViewById(R.id.user_password_create);
        passTextConfirm = findViewById(R.id.user_password_create_confirm);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = nameTxt.getText().toString();
                password = passTxt.getText().toString();
                passwordConfirm = passTextConfirm.getText().toString();

                if(password.equals(passwordConfirm)){
                    String authToken = createAuthToken(name, password);
                    checkCreateDetails(authToken);
                }
                else{

                    Toast.makeText(getApplicationContext(),"Senhas diferentes!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void checkCreateDetails(String authToken){
        Retrofit retrofit = RetrofitClientInstance.getRetrofitInstance();
        final InterfaceAPI api = retrofit.create(InterfaceAPI.class);


        Call<JsonObject> call = api.checkCadastro(name, password);

        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(response.isSuccessful()){
                    Toast.makeText(getApplicationContext(),"Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), PanelActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(),"Usuário indisponível!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("TAG", t.toString());
                t.printStackTrace();
                Toast.makeText(getApplicationContext(),"Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private String createAuthToken(String name, String password){
        byte[] data = new byte[0];

        try {

            data = (name + ":" + password).getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return Base64.encodeToString(data, Base64.NO_WRAP);
    }
}