package com.example.alltogether.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alltogether.R;

public class PanelActivity extends AppCompatActivity {
    private Button thirdButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel);

        thirdButton = (Button) findViewById(R.id.yfin_button);
        thirdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStockScreen();
            }
        });
    }

    public void openStockScreen(){
        Intent intent = new Intent(this, StockActivity.class);
        startActivity(intent);
    }
}