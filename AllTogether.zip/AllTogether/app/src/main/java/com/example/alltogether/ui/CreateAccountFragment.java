package com.example.alltogether.ui;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.alltogether.R;
import com.example.alltogether.databinding.FragmentCreateAccountBinding;
import com.example.alltogether.databinding.FragmentLoginBinding;


public class CreateAccountFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FragmentCreateAccountBinding binding = DataBindingUtil.inflate(inflater, R.layout.fragment_create_account, container, false);
        return binding.getRoot();
    }
}