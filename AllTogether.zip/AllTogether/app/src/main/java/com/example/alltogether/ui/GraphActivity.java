package com.example.alltogether.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.alltogether.R;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.LineRadarDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.gson.Gson;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Map;

public class GraphActivity extends AppCompatActivity {

    private LineChart mChart;
    private int jsonLength;
    private Button button, buttonDoubtData, buttonDoubtOpen, buttonDoubtHigh, buttonDoubtLow, buttonDoubtClose;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        String trueFinalJson = getIntent().getExtras().getString(StockActivity.MY_FINAL_JSON);
        GetElementsFinalList graphJson = new Gson().fromJson(trueFinalJson, GetElementsFinalList.class);
        graphJson.getFinalJsonStock().get(0).getOpenValue();
        jsonLength = graphJson.getFinalJsonStock().size();
        TextView valueDate = findViewById(R.id.date_value_number);
        TextView numberOpen = findViewById(R.id.open_value_number);
        TextView numberHigh = findViewById(R.id.high_value_number);
        TextView numberLow = findViewById(R.id.low_value_number);
        TextView numberClose = findViewById(R.id.close_value_number);

        mChart = (LineChart) findViewById(R.id.line_graph);

        //mChart.setOnChartGestureListener((OnChartGestureListener) GraphActivity.this);
        //mChart.setOnChartValueSelectedListener((OnChartValueSelectedListener) GraphActivity.this);

        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(false);

        ArrayList<Entry> yValues = new ArrayList<Entry>();

        yValues.add(new Entry(0, graphJson.getFinalJsonStock().get(jsonLength - 6).getOpenValue()));
        yValues.add(new Entry(1, graphJson.getFinalJsonStock().get(jsonLength - 5).getOpenValue()));
        yValues.add(new Entry(2, graphJson.getFinalJsonStock().get(jsonLength - 4).getOpenValue()));
        yValues.add(new Entry(3, graphJson.getFinalJsonStock().get(jsonLength - 3).getOpenValue()));
        yValues.add(new Entry(4, graphJson.getFinalJsonStock().get(jsonLength - 2).getOpenValue()));
        yValues.add(new Entry(5, graphJson.getFinalJsonStock().get(jsonLength - 1).getOpenValue()));
        //yValues.add(new Entry(6, graphJson.getFinalJsonStock().get(jsonLength).getOpenValue()));
        //yValues.add(new Entry(7, 60f));
        LineRadarDataSet set1 = new LineDataSet(yValues, "Valores de abertura da ação");


        set1.setFillAlpha(110);

        set1.setColor(Color.RED);
        set1.setLineWidth(3f);
        set1.setValueTextSize(15f);
        set1.setValueTextColor(Color.BLUE);
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add((ILineDataSet) set1);

        LineData data = new LineData(dataSets);

        mChart.setData(data);

        numberOpen.setText(graphJson.getFinalJsonStock().get(jsonLength - 1).getOpenValue().toString());
        numberHigh.setText(graphJson.getFinalJsonStock().get(jsonLength - 1).getHighValue().toString());
        numberLow.setText(graphJson.getFinalJsonStock().get(jsonLength - 1).getLowValue().toString());
        numberClose.setText(graphJson.getFinalJsonStock().get(jsonLength - 1).getCloseValue().toString());
        valueDate.setText(graphJson.getFinalJsonStock().get(jsonLength - 1).getDayValue());

        buttonDoubtData = (Button) findViewById(R.id.more_info_data);
        buttonDoubtData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogData();
            }
        });

        buttonDoubtOpen = (Button) findViewById(R.id.more_info_open);
        buttonDoubtOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogOpen();
            }
        });

        buttonDoubtHigh = (Button) findViewById(R.id.more_info_high);
        buttonDoubtHigh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogHigh();
            }
        });

        buttonDoubtLow = (Button) findViewById(R.id.more_info_low);
        buttonDoubtLow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogLow();
            }
        });

        buttonDoubtClose = (Button) findViewById(R.id.more_info_close);
        buttonDoubtClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogClose();
            }
        });

        button = (Button) findViewById(R.id.back_graph_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToStockScreen();
            }
        });
    }

    public void openDialogData(){
        DialogData exampleDialog = new DialogData();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    public void openDialogOpen(){
        DialogOpen exampleDialog = new DialogOpen();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    public void openDialogHigh(){
        DialogHigh exampleDialog = new DialogHigh();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    public void openDialogLow(){
        DialogLow exampleDialog = new DialogLow();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    public void openDialogClose(){
        DialogClose exampleDialog = new DialogClose();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    public void backToStockScreen(){
        Intent intent = new Intent(this, StockActivity.class);
        startActivity(intent);
    }
}