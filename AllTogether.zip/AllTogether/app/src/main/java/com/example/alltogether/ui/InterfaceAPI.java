package com.example.alltogether.ui;

import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface InterfaceAPI {
    @POST("/login")
    Call<JsonObject> checkLogin(@Header("login") String headerUser, @Header("password") String headerPass);

    @POST("/cadastro")
    Call<JsonObject> checkCadastro(@Header("login") String headerUser, @Header("password") String headerPass);

    @GET("/yfinan")
    Call<GetElementsFinalList> checkStock(@Header("stock") String headerStock);
}
